main()
{

    x5,y5,x3,x2,x1:int;
	x5=y5=2+x3=1+x2=2*x1=(2+2)%3;
	print(x1);
	print(x2);
	print(x3);
	print(x5);
	print(y5);

	v5,x[6],y[6]:int;
	v5=x[5]=y[5]=2+x[3]=1+x[2]=2*x[1]=(6-2)%3;
	print(v5);
	x1 = x[1];
	x2 = x[2];
	x3 = x[3];
	x5 = x[5];
	y5 = y[5];
	print(x1);
	print(x2);
	print(x3);
	print(x5);
	print(y5);

	i1 = 3 ,i2 = 4 ,i3 = 5:int;
    i1 = i1 * i1 / i1 + (i2 / 2 * (i3 + i3 / i2)) ;
    print(i1);
}
